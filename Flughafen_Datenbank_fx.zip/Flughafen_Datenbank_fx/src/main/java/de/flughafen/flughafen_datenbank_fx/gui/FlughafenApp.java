package de.flughafen.flughafen_datenbank_fx.gui;

import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.stage.Stage;

public class FlughafenApp extends Application {

    @Override
    public void start(Stage primaryStage) throws Exception {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("main.fxml"));
        primaryStage.setTitle("Flughafen Verwaltung");
        primaryStage.setScene(new Scene(loader.load(), 900, 900));
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}