package de.flughafen.flughafen_datenbank_fx.gui;

public class Airline {
    private int id;
    private String name;
    private int anzahlFlugzeuge;
    private int flugzeugeF;

    public Airline(int id, String name, int anzahlFlugzeuge, int flugzeugeF) {
        this.id = id;
        this.name = name;
        this.anzahlFlugzeuge = anzahlFlugzeuge;
        this.flugzeugeF = flugzeugeF;
    }

    public int getId() { return id; }
    public String getName() { return name; }
    public int getAnzahlFlugzeuge() { return anzahlFlugzeuge; }
    public int getFlugzeugeF() { return flugzeugeF; }}