package de.flughafen.flughafen_datenbank_fx.gui;

import de.flughafen.flughafen_datenbank_fx.Datenbank_Flughafen;
import javafx.fxml.FXML;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;

public class FlughafenController {

    @FXML
    private TableView<Airline> tableView;
    @FXML
    private TableColumn<Airline, Integer> idColumn;
    @FXML
    private TableColumn<Airline, String> nameColumn;
    @FXML
    private TableColumn<Airline, Integer> anzahlColumn;
    @FXML
    private TableColumn<Airline, Integer> flugzeugeFColumn;

    private Datenbank_Flughafen db = new Datenbank_Flughafen();
    private ObservableList<Airline> airlines = FXCollections.observableArrayList();

    @FXML
    public void initialize() {
        idColumn.setCellValueFactory(new PropertyValueFactory<>("id"));
        nameColumn.setCellValueFactory(new PropertyValueFactory<>("name"));
        anzahlColumn.setCellValueFactory(new PropertyValueFactory<>("anzahlFlugzeuge"));
        flugzeugeFColumn.setCellValueFactory(new PropertyValueFactory<>("flugzeugeF"));
        refreshTable();
    }

    @FXML
    public void refreshTable() {
        airlines.clear();
        try (var rs = db.getAllAirlines()) {
            while (rs.next()) {
                airlines.add(new Airline(
                        rs.getInt("AirlineID"),
                        rs.getString("Name"),
                        rs.getInt("AnzahlFlugzeuge"),
                        rs.getInt("Flugzeuge_F")
                ));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        tableView.setItems(airlines);
    }

    @FXML
    public void addAirline() {
        TextInputDialog nameDialog = new TextInputDialog();
        nameDialog.setHeaderText("Name der Airline");
        String name = nameDialog.showAndWait().orElse(null);

        TextInputDialog anzahlDialog = new TextInputDialog();
        anzahlDialog.setHeaderText("Anzahl Flugzeuge");
        int anzahl = Integer.parseInt(anzahlDialog.showAndWait().orElse("0"));

        TextInputDialog flugzeugeFDialog = new TextInputDialog();
        flugzeugeFDialog.setHeaderText("Flugzeuge_F");
        int flugzeugeF = Integer.parseInt(flugzeugeFDialog.showAndWait().orElse("0"));

        db.addAirline(name, anzahl, flugzeugeF);
        refreshTable();
    }

    @FXML
    public void deleteAirline() {
        Airline selected = tableView.getSelectionModel().getSelectedItem();
        if (selected != null) {
            db.deleteAirlineByID(selected.getId());
            refreshTable();
        }
    }

    @FXML
    public void editAirline() {
        Airline selected = tableView.getSelectionModel().getSelectedItem();
        if (selected == null) {
            Alert alert = new Alert(Alert.AlertType.WARNING, "Bitte wählen Sie eine Airline aus, die bearbeitet werden soll.");
            alert.showAndWait();
            return;
        }

        // Eingabedialoge mit aktuellen Werten
        TextInputDialog nameDialog = new TextInputDialog(selected.getName());
        nameDialog.setHeaderText("Neuer Name der Airline:");
        String newName = nameDialog.showAndWait().orElse(selected.getName());

        TextInputDialog anzahlDialog = new TextInputDialog(String.valueOf(selected.getAnzahlFlugzeuge()));
        anzahlDialog.setHeaderText("Neue Anzahl Flugzeuge:");
        int newAnzahl = Integer.parseInt(anzahlDialog.showAndWait().orElse(String.valueOf(selected.getAnzahlFlugzeuge())));

        TextInputDialog flugzeugeFDialog = new TextInputDialog(String.valueOf(selected.getFlugzeugeF()));
        flugzeugeFDialog.setHeaderText("Neue Flugzeug-Art (1–11):");
        int newFlugzeugeF = Integer.parseInt(flugzeugeFDialog.showAndWait().orElse(String.valueOf(selected.getFlugzeugeF())));

        // Update in der Datenbank
        db.updateAirlineByID(selected.getId(), newName, String.valueOf(newAnzahl), newFlugzeugeF);

        // Tabelle aktualisieren
        refreshTable();
    }

}
